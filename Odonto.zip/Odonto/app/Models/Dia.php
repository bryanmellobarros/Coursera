<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dia extends Model
{
    use HasFactory;

    protected $fillable = ['internacao_id', 'data', 'sedacao', 'ventilacao', 'mucosas', 'hipotese_diagnostica', 'presenca', 'salivacao',
    'dentes', 'conduta', 'prescricao', 'observacoes', 'intercorrencias', 'odontologista'];
}
