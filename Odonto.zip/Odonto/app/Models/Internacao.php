<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Internacao extends Model
{
    use HasFactory;

    protected $fillable = ['paciente_id', 'data_de_entrada', 'data_de_saida', 'motivo_da_internacao',
    'pa', 'sato2', 'fc', 'fr', 'temp', 'dieta', 'bomba_de_infusao', 'hemodialise', 'risco_de_tev',
    'conduta_profilatica_tev'];
}
