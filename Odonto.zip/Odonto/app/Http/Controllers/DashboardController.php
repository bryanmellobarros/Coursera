<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{

    public function index()
    {
        // Aqui, você pode passar algum dado inicial, como o mês atual.
        $mes = date('2024-10');  // Pega o mês atual
        return view('dashboard', compact('mes')); // Chama a view e passa o mês
    }
    public function dashboard(Request $request){
        $mes = $request->query('mes', date('Y-m'));

        // Consulta ao banco de dados, buscando atendimentos por dentista no mês
        $atendimentos = DB::table('dias')
            ->select(DB::raw('odontologista, COUNT(*) as atendimentos'))
            ->whereRaw("DATE_FORMAT(data, '%Y-%m') = ?", [$mes])
            ->groupBy('odontologista')
            ->get();

        // Retorna os dados em formato JSON
        return response()->json($atendimentos);
    }
}
