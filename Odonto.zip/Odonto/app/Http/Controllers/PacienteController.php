<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Paciente;
use \App\Models\Internacao;;

class PacienteController extends Controller
{
    public function listAll(){
        $data = Paciente::all()->toArray();
        return view('pacientesList', ['data'=>$data]);
    }

    public function listFilter(){
        //$data = Paciente::all()->toArray();
        $filter = '%'.$_GET['query'].'%';
        $data = Paciente::where('nome', 'like', $filter)->get()->toArray();
        //$data = Paciente::where('nome', 'like', '%Bryan%')->toArray();
        return view('pacientesList', ['data'=>$data]);
    }

    public function pacienteEdit($id){
        $data = Paciente::where('id', '=', $id)->get()->toArray();
        $data2 = Internacao::where('paciente_id', '=', $id)->get()->toArray();
        return view('pacientesEdit', ['data'=>$data, 'data2'=>$data2]);
    }

    public function saving($id, Request $request){
        $paciente = Paciente::find($id);
        $paciente->fill([
            'nome'=>$request->input('nome'),
            'idsjb'=>$request->input('idsjb'),
            'data_de_nascimento'=>$request->input('data_de_nascimento'),
            'sexo'=>$request->input('sexo'),
            'comorbidades'=>$request->input('comorbidades')
        ]);
        $paciente->save();

        return $this->pacienteEdit($id);
    }

    public function add(){
        return view('pacientesAdd');
    }

    public function adding(Request $request){
        $paciente = new Paciente();
        $paciente->fill([
            'nome'=>$request->input('nome'),
            'idsjb'=>$request->input('idsjb'),
            'data_de_nascimento'=>$request->input('data_de_nascimento'),
            'sexo'=>$request->input('sexo'),
            'comorbidades'=>$request->input('comorbidades')
        ]);
        $paciente->save();
        $id = Paciente::latest()->first()->id;
        return $this->pacienteEdit($id);
    }
}
