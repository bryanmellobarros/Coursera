<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Dia;

class DiaController extends Controller
{
    public function showDia($id){
        $data = Dia::where('id', '=', $id)->get()->toArray();
        return view('diaEdit', ['data'=>$data]);
    }

    public function saving($id, Request $request){
        $condutas = $request->input('conduta');
        $condutasCerto = '';
        foreach($condutas as $conduta){
            $condutasCerto.=$conduta.';';
        }

        $dentes = $request->input('dentes');
        $dentesCerto = '';
        foreach($dentes as $dente){
            $dentesCerto.=$dente.';';
        }

        $presencas = $request->input('presenca');
        $presencasCerto = '';
        foreach($presencas as $presenca){
            $presencasCerto.=$presenca.';';
        }
        $dia = Dia::find($id);
        $dia->fill([
            'sedacao'=>$request->input('sedacao'),
            'ventilacao'=>$request->input('ventilacao'),
            'mucosas'=>$request->input('mucosas'),
            'hipotese_diagnostica'=>$request->input('hipotese_diagnostica'),
            'presenca'=>$presencasCerto,
            'salivacao'=>$request->input('salivacao'),
            'dentes'=>$dentesCerto,
            'conduta'=>$condutasCerto,
            'prescricao'=>$request->input('prescricao'),
            'observacoes'=>$request->input('observacoes'),
            'intercorrencias'=>$request->input('intercorrencias')
        ]);
        $dia->save();

        return $this->showDia($id);
    }

    public function add($id){
        return view('diaAdd', ['id'=>$id]);
    }

    public function adding($id, Request $request){
        $condutas = $request->input('conduta');
        $condutasCerto = '';
        foreach($condutas as $conduta){
            $condutasCerto.=$conduta.';';
        }

        $dentes = $request->input('dentes');
        $dentesCerto = '';
        foreach($dentes as $dente){
            $dentesCerto.=$dente.';';
        }

        $presencas = $request->input('presenca');
        $presencasCerto = '';
        foreach($presencas as $presenca){
            $presencasCerto.=$presenca.';';
        }
        $dia = new Dia();
        $dia->fill([
            'internacao_id'=>$id,
            'data'=>$request->input('data'),
            'sedacao'=>$request->input('sedacao'),
            'ventilacao'=>$request->input('ventilacao'),
            'mucosas'=>$request->input('mucosas'),
            'hipotese_diagnostica'=>$request->input('hipotese_diagnostica'),
            'presenca'=>$presencasCerto,
            'salivacao'=>$request->input('salivacao'),
            'dentes'=>$dentesCerto,
            'conduta'=>$condutasCerto,
            'prescricao'=>$request->input('prescricao'),
            'observacoes'=>$request->input('observacoes'),
            'intercorrencias'=>$request->input('intercorrencias'),
            'odontologista'=>$request->input('odontologista')
        ]);
        $dia->save();
        $id = Dia::latest()->first()->id;
        return $this->showDia($id);
    }
}
