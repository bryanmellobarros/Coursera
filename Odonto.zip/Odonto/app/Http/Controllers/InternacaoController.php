<?php

namespace App\Http\Controllers;
use \App\Models\Internacao;
use \App\Models\Dia;
use \App\Models\Paciente;

use Illuminate\Http\Request;

class InternacaoController extends Controller
{
    public function showData($id){
        $data = Internacao::where('id', '=', $id)->get()->toArray();
        $data2 = Dia::where('internacao_id', '=', $id)->get()->toArray();
        return view('internacaoEdit', ['data'=>$data, 'data2'=>$data2]);
    }

    public function saving($id, Request $request){
        $internacao = Internacao::find($id);
        $internacao->fill([
            'data_de_entrada'=>$request->input('data_de_entrada'),
            'data_de_saida'=>$request->input('data_de_saida'),
            'motivo_da_internacao'=>$request->input('motivo_da_internacao'),
            'pa'=>$request->input('pa'),
            'sato2'=>$request->input('sato2'),
            'fc'=>$request->input('fc'),
            'fr'=>$request->input('fr'),
            'temp'=>$request->input('temp'),
            'dieta'=>$request->input('dieta'),
            'bomba_de_infusao'=>$request->input('bomba_de_infusao'),
            'hemodialise'=>$request->input('hemodialise'),
            'risco_de_tev'=>$request->input('risco_de_tev'),
            'conduta_profilatica_tev'=>$request->input('conduta_profilatica_tev')
        ]);
        $internacao->save();

        return $this->showData($id);
    }

    public function add($id){
        $paciente = Paciente::find($id);
        $nome = $paciente['nome'];
        return view('internacaoAdd', ['nome'=>$paciente['nome'], 'id'=>$paciente['id']]);
    }

    public function adding(Request $request, $id){
        $internacao = new Internacao();
        $internacao->fill([
            'paciente_id'=>$id,
            'data_de_entrada'=>$request->input('data_de_entrada'),
            'data_de_saida'=>$request->input('data_de_saida'),
            'motivo_da_internacao'=>$request->input('motivo_da_internacao'),
            'pa'=>$request->input('pa'),
            'sato2'=>$request->input('sato2'),
            'fc'=>$request->input('fc'),
            'fr'=>$request->input('fr'),
            'temp'=>$request->input('temp'),
            'dieta'=>$request->input('dieta'),
            'bomba_de_infusao'=>$request->input('bomba_de_infusao'),
            'hemodialise'=>$request->input('hemodialise'),
            'risco_de_tev'=>$request->input('risco_de_tev'),
            'conduta_profilatica_tev'=>$request->input('conduta_profilatica_tev')
        ]);
        $internacao->save();
        $id = Internacao::latest()->first()->id;
        return $this->showData($id);

    }
}
