<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfico de Atendimentos dos Dentistas</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        #myChart {
            width: 80%;
            height: 400px;
            margin: auto;
        }
        .container {
            text-align: center;
        }
        .button-container {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Atendimentos por Dentista</h2>

        <!-- Botões para alterar o mês -->
        <div class="button-container">
            <button onclick="alterarMes('2024-01')">Janeiro</button>
            <button onclick="alterarMes('2024-02')">Fevereiro</button>
            <button onclick="alterarMes('2024-03')">Março</button>
            <button onclick="alterarMes('2024-04')">Abril</button>
            <button onclick="alterarMes('2024-10')">Maio</button>
        </div>

        <!-- Canvas para o gráfico -->
        <canvas id="myChart"></canvas>
    </div>

    <script>
        // Variáveis globais
        let myChart;

        // Função para alterar o mês e atualizar o gráfico
        function alterarMes(mes) {
            fetch(`/api/atendimentos?mes=${mes}`)
                .then(response => response.json())
                .then(data => {
                    atualizarGrafico(data);
                })
                .catch(error => {
                    console.error('Erro ao buscar dados:', error);
                });
        }

        // Função para atualizar o gráfico com novos dados
        function atualizarGrafico(data) {
            const dentistas = data.map(item => item.dentista);
            const atendimentos = data.map(item => item.atendimentos);

            // Se o gráfico já existe, destruímos ele para recriar
            if (myChart) {
                myChart.destroy();
            }

            // Criando o gráfico
            const ctx = document.getElementById('myChart').getContext('2d');
            myChart = new Chart(ctx, {
                type: 'bar', // Tipo de gráfico (barras)
                data: {
                    labels: dentistas, // Dentistas como rótulos
                    datasets: [{
                        label: 'Atendimentos',
                        data: atendimentos, // Dados dos atendimentos
                        backgroundColor: 'rgba(75, 192, 192, 0.2)', // Cor de fundo das barras
                        borderColor: 'rgba(75, 192, 192, 1)', // Cor da borda das barras
                        borderWidth: 1 // Espessura da borda
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                });
        }

        // Carregar os dados iniciais (padrão para Janeiro de 2024)
        alterarMes('2024-10');
    </script>

</body>
</html>
