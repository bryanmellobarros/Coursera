@extends('layouts.index')
@section('conteudo')
    <style>
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; /* Remove qualquer sombra */
            border: 2px solid;
            border-color: lightgray;
        }
        .formulario {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content: center;
            align-items: center
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .table{
            padding-right: 10px;
        }
        .segunda_linha{
            padding-left: 10px;
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
        .enter_internacao .finish_internacao{
            height: 10px;
            width: 10px;
        }
        .btn_add {
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            height: 35px;
        }
        .btn_add:hover {
            background-color: #4100f3;
        }
        .return_btn{
            display: flex;
            align-items: center;
            background-color: white;
            width: 100px;
        }
    </style>
    <div style="background-color: white;">
        <div style="border-radius: 10px; background-color:lightgray" class="return_btn">
            <a href="{{route('site.pacientesEdit', $id)}}"><span class="material-symbols-outlined">arrow_back</span></a><span style="padding-left: 5px;">Retornar</span>
        </div>
    </div>
    <div>
        <h1>Adicionando Internação para Paciente: {{$nome}}</h1>
        <hr>
    </div>
    <div>
        <form action="{{route('site.adicionarInternacao',$id)}}" method="POST">
            @csrf
            <div class="formulario">
                <div class="primeira_coluna">
                    <label>Data de Entrada</label><br>
                    <input type="date" value="{{date('Y-m-d')}}" name="data_de_entrada"><br><br>
                    <label>Data de Saída</label><br>
                    <input type="date" value="" name="data_de_saida"><br><br>
                    <h2>Monitor Cardíaco</h2>
                    <label>PA</label><br>
                    <input type="text" value="" name="pa"><br><br>
                    <label>SATO2</label><br>
                    <input type="text" value="" name="sato2"><br><br>
                    <label>FC</label><br>
                    <input type="text" value="" name="fc"><br><br>
                    <label>FR</label><br>
                    <input type="text" value="" name="fr"><br><br>
                    <label>TEMP</label><br>
                    <input type="text" value="" name="temp"><br><br>
                </div>
                <div class='segunda_coluna'>
                    <label>Bomba de Infusão</label><br>
                    <select name="bomba_de_infusao"><option value="1">Sim</option><option value="2">Não</option></select>
                    <br><br>
                    <label>Hemodialise</label><br>
                    <select name="hemodialise"><option value="1">Sim</option><option value="2">Não</option></select>
                    <br><br>
                    <label>Risco de TEV</label><br>
                    <select name="risco_de_tev"><option value="1">Sim</option><option value="2">Não</option></select>
                    <br><br>
                    <label>Conduta Profilática TEV</label><br>
                    <textarea name="conduta_profilatica_tev"></textarea><br><br>
                    <label>Motivo da Internação</label><br>
                    <textarea name="motivo_da_internacao"></textarea>
                </div>
            </div>
            <br>
            <div style="text-align: center;width:100%">
                <button class="atualizar" type="submit" style="border-radius: 10px;font-size:15px">Salvar</button>
            </div>
            <br>
        </form>
    </div>
@endsection