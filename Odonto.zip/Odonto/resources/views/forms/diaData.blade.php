@php
    $stringRecebida = $data[0]['presenca'];
    $valores = explode(';', trim($stringRecebida, ';'));
    $opcoesCheckbox = [
        'biofilme_visivel',
        'saburra_lingual',
        'tartaro',
        'aresta',
        'sangramento',
        'carie',
        'raiz_ou_raizes_residuais',
        'sinal_flogisticos'
    ];

    $stringRecebida2 = $data[0]['dentes'];
    $valores2 = explode(';', trim($stringRecebida2, ';'));
    $opcoesCheckbox2 = [
        'edentado_total_superior',
        'edentado_total_inferior',
        'edentado_parcial_superior',
        'edentado_parcial_inferior',
        'dentado_total_superior',
        'dentado_total_inferior'
    ];

    $stringRecebida3 = $data[0]['conduta'];
    $valores3 = explode(';', trim($stringRecebida3, ';'));
    $opcoesCheckbox3 = [
        'solucao_enzimatica',
        'clorexidine_0,12%',
        'clorexidine_gel_0,2%',
        'saliva_artificial',
        'bepantol_baby',
        'higienizacao_proteses',
        'aspiracao_orofaringe',
        'secretivo',
        'laser',
        'restauracao',
        'extracao',
        'sutura',
        'protese',
    ];

@endphp
<div>
    <form action="{{route('site.diaSaving', $data[0]['id'])}}" method="POST">
        @csrf
        <div class="formulario" style="display: flex">
            <div class="primeira_coluna" style="flex: 1;border-right:2px solid;align-content:flex-start">
                @php
                    $dateTime = DateTime::createFromFormat('Y-m-d', $data[0]['data']);
                    $datetime = $dateTime->format('d/m/Y');
                @endphp
                <h2>Atendimento no dia: {{$datetime}}</h2>
                <label>Sedação</label><br>
                @if ($data[0]['sedacao']==1)
                    <select name="sedacao"><option value="1" selected>Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==2)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2" selected>Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==3)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3" selected>Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==4)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4" selected>Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==5)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5" selected>Lote</option><option value="6" >Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==6)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6" selected>Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==7)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7" selected>Interagindo</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['sedacao']==8)
                    <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8" selected>Colaborativo</option></select>
                @endif
                <br><br>
                <label>Ventilação</label><br>
                @if ($data[0]['ventilacao']==1)
                    <select name="ventilacao"><option value="1" selected>Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==2)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2" selected>Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==3)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3" selected>Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==4)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4" selected>VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==5)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5" selected>TQT</option><option value="6" >TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==6)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6" selected>TOT</option><option value="7">VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @elseif ($data[0]['ventilacao']==7)
                    <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7" selected>VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                @endif
                <br><br>
                <label>Mucosas</label><br>
                @if ($data[0]['mucosas']==1)
                    <select name="mucosas"><option value="1" selected>Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==2)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2" selected>Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==3)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3" selected>Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==4)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4" selected>Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==5)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5" selected>Hidratadas</option><option value="6" >Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==6)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6" selected>Hígidas</option><option value="7">Lesão</option></select>
                @elseif ($data[0]['mucosas']==7)
                    <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7" selected>Lesão</option></select>
                @endif
                <br><br>
                <label>Salivação</label><br>
                @if ($data[0]['salivacao']==1)
                    <select name="salivacao"><option value="1" selected>Normal</option><option value="2">Xerostomia</option><option value="3">Hipossalivação</option><option value="4">Babação</option></select>
                @elseif ($data[0]['salivacao']==2)
                    <select name="salivacao"><option value="1">Normal</option><option value="2" selected>Xerostomia</option><option value="3">Hipossalivação</option><option value="4">Babação</option></select>
                @elseif ($data[0]['salivacao']==3)
                    <select name="salivacao"><option value="1">Normal</option><option value="2">Xerostomia</option><option value="3" selected>Hipossalivação</option><option value="4">Babação</option></select>
                @elseif ($data[0]['salivacao']==4)
                    <select name="salivacao"><option value="1">Normal</option><option value="2">Xerostomia</option><option value="3">Hipossalivação</option><option value="4" selected>Babação</option></select>
                @endif
                <br><br>
                <div class="multiplas_escolhas" style="display: flex">
                    <div class="presenca" style="flex: 1">
                        <label>Presença</label><br>
                        @foreach ($opcoesCheckbox as $item)
                            @if (in_array($item, $valores))
                                <input type="checkbox" value={{$item}} name="presenca[]" id='{{$item}}' checked>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @else
                                <input type="checkbox" value={{$item}} name="presenca[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @endif
                        @endforeach
                    </div>
                    <div class="dentes" style="flex: 1">
                        <label>Dentes</label><br>
                        @foreach ($opcoesCheckbox2 as $item)
                            @if (in_array($item, $valores2))
                                <input type="checkbox" value={{$item}} name="dentes[]" id='{{$item}}' checked>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @else
                                <input type="checkbox" value={{$item}} name="dentes[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @endif
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="segunda_coluna" style="flex: 1;align-content:flex-start;padding-top:80px">
                <label>Conduta</label><br>
                @foreach ($opcoesCheckbox3 as $item)
                    @if (in_array($item, $valores3))
                        <input type="checkbox" value={{$item}} name="conduta[]" id='{{$item}}' checked>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                    @else
                        <input type="checkbox" value={{$item}} name="conduta[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                    @endif
                @endforeach
                <br><br>
                <label>Prescrição</label><br>
                <textarea name="prescricao">{{$data[0]['prescricao']}}</textarea><br><br>
                <label>Observações</label><br>
                <textarea name="observacoes">{{$data[0]['observacoes']}}</textarea><br><br>
                <label>Intercorrencias</label><br>
                <textarea name="intercorrencias">{{$data[0]['intercorrencias']}}</textarea><br><br>
            </div>
        </div>
        <br>
        <div style="text-align: center;width:100%">
            <button class="atualizar" type="submit" style="border-radius: 10px;font-size:15px">{{$nome_btn}}</button>
        </div>
    </form>
    <br>
<div>