<div>
    <form action='{{route('site.pacienteSaving', $data[0]['id'])}}' method="POST">
        @csrf
        <div class="formulario_edit">
            <div class="primeira_coluna">
                <label>Nome</label><br>
                <input type="text" value="{{$data[0]['nome']}}" required name="nome"><br><br><br>
                <label>Data de Nascimento</label><br>
                <input type="date" value="{{$data[0]['data_de_nascimento']}}" required name="data_de_nascimento"><br>
            </div>
            <div class="segunda_coluna">
                <label>ID São Jão Batista</label><br>
                <input type="text" value="{{$data[0]['idsjb']}}" required name="idsjb"><br><br><br>
                <label>Sexo</label><br>
                @if ($data[0]['sexo']=='M')
                    <select name="sexo"><option value="M" selected>Masculino</option><option value="F">Feminino</option></select><br>
                @else
                <select name="sexo"><option value="M">Masculino</option><option value="F" selected>Feminino</option></select><br>
                @endif
            </div>
        </div>
        <br>
        <div class='segunda_linha'>
            <label>Comorbidades</label><br>
            <textarea name="comorbidades">{{$data[0]['comorbidades']}}</textarea>
        </div>
        <br><br>
        <div style="text-align: center;width:100%">
        <button class="atualizar" type="submit" style="border-radius: 10px;font-size:15px">{{$nome_btn}}</button>
        </div>
    </form>
</div>