<div>
    <form action="{{route('site.internacaoSaving', $data[0]['id'])}}" method="POST">
        @csrf
        <div class="formulario">
            <div class="primeira_coluna">
                <label>Data de Entrada</label><br>
                <input type="date" value="{{$data[0]['data_de_entrada']}}" name="data_de_entrada"><br><br>
                <label>Data de Saída</label><br>
                <input type="date" value="{{$data[0]['data_de_saida']}}" name="data_de_saida"><br><br>
                <h2>Monitor Cardíaco</h2>
                <label>PA</label><br>
                <input type="text" value="{{$data[0]['pa']}}" name="pa"><br><br>
                <label>SATO2</label><br>
                <input type="text" value="{{$data[0]['sato2']}}" name="sato2"><br><br>
                <label>FC</label><br>
                <input type="text" value="{{$data[0]['fc']}}" name="fc"><br><br>
                <label>FR</label><br>
                <input type="text" value="{{$data[0]['fr']}}" name="fr"><br><br>
                <label>TEMP</label><br>
                <input type="text" value="{{$data[0]['temp']}}" name="temp"><br><br>
            </div>
            <div class='segunda_coluna'>
                <label>Bomba de Infusão</label><br>
                @if($data[0]['bomba_de_infusao']==1)
                    <select name="bomba_de_infusao"><option value="1" selected>Sim</option><option value="2">Não</option></select>
                @else
                    <select name="bomba_de_infusao"><option value="1">Sim</option><option value="2" selected>Não</option></select>
                @endif
                <br><br>
                <label>Hemodialise</label><br>
                @if($data[0]['hemodialise']==1)
                    <select name="hemodialise"><option value="1" selected>Sim</option><option value="2">Não</option></select>
                @else
                    <select name="hemodialise"><option value="1">Sim</option><option value="2" selected>Não</option></select>
                @endif
                <br><br>
                <label>Risco de TEV</label><br>
                @if($data[0]['risco_de_tev']==1)
                    <select name="risco_de_tev"><option value="1" selected>Sim</option><option value="2">Não</option></select>
                @else
                    <select name="risco_de_tev"><option value="1">Sim</option><option value="2" selected>Não</option></select>
                @endif
                <br><br>
                <label>Conduta Profilática TEV</label><br>
                <textarea name="conduta_profilatica_tev">{{$data[0]['conduta_profilatica_tev']}}</textarea><br><br>
                <label>Motivo da Internação</label><br>
                <textarea name="motivo_da_internacao">{{$data[0]['motivo_da_internacao']}}</textarea>
            </div>
        </div>
        <br>
        <div style="text-align: center;width:100%">
            <button class="atualizar" type="submit" style="border-radius: 10px;font-size:15px">{{$nome_btn}}</button>
        </div>
        <br>
    </form>
</div>