@extends('layouts.index')
@section('conteudo')
    <style>
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; /* Remove qualquer sombra */
            border: 2px solid;
            border-color: lightgray;
        }
        .formulario_edit {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content: center;
            align-items: center
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .table{
            padding-right: 10px;
        }
        .segunda_linha{
            padding-left: 10px;
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
        .enter_internacao .finish_internacao{
            height: 10px;
            width: 10px;
        }
        .btn_add {
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            height: 35px;
        }
        .btn_add:hover {
            background-color: #4100f3;
        }
    </style>
    <div>
        <h1>Paciente: {{$data[0]['nome']}}</h1>
        <hr>
    </div>
    @component('forms.pacientesData', ['data'=>$data, 'nome_btn'=>'Atualizar'])
        
    @endcomponent
    <br>
    <hr>
    <br>
    <div style="text-align: right;padding-right:35px">
        <a href="{{route('site.adicionarInternacao', $data[0]['id'])}}"><button class="btn_add">Adicionar Internação</button></a>
    </div>
    <h2>Internações</h2>
    <div class="table">
        <table>
            <thead>
                <tr>
                    <th>Data de Entrada</th>
                    <th>Data de Saída</th>
                    <th>Motivo da Internação</th>
                    <th>Dias</th>
                    <th>Opções</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data2 as $d)
                    <tr>
                        <td>{{ $d['data_de_entrada'] }}</td>
                        <td>{{ $d['data_de_saida'] }}</td>
                        <td>{{ $d['motivo_da_internacao'] }}</td>
                        <td>Dias</td>
                        <td><a href="{{route('site.internacaoEdit', $d['id'])}}"><span class="material-symbols-outlined" class="enter_internacao" style="margin-right: 10px;">arrow_forward</span></a><a href="#"><span class="material-symbols-outlined">check</span></a></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <br>
        <br>
    </div>
@endsection