@extends('layouts.index')
@section('conteudo')
    <style>
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; /* Remove qualquer sombra */
            border: 2px solid;
            border-color: lightgray;
        }
        .formulario_edit {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content: center;
            align-items: center
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .table{
            padding-right: 10px;
        }
        .segunda_linha{
            padding-left: 10px;
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
        .enter_internacao .finish_internacao{
            height: 10px;
            width: 10px;
        }
    </style>
    <div>
        <h1>Adicionando paciente</h1>
        <hr>
    </div>
    <div>
        <form action='{{route('site.pacienteAdd')}}' method="POST">
            @csrf
            <div class="formulario_edit">
                <div class="primeira_coluna">
                    <label>Nome</label><br>
                    <input type="text" value="" required name="nome"><br><br><br>
                    <label>Data de Nascimento</label><br>
                    <input type="date" value="" required name="data_de_nascimento"><br>
                </div>
                <div class="segunda_coluna">
                    <label>ID São Jão Batista</label><br>
                    <input type="text" value="" required name="idsjb"><br><br><br>
                    <label>Sexo</label><br>
                    <select name="sexo"><option value="M">Masculino</option><option value="F">Feminino</option></select><br>
                </div>
            </div>
            <br>
            <div class='segunda_linha'>
                <label>Comorbidades</label><br>
                <textarea name="comorbidades"></textarea>
            </div>
            <br><br>
            <div style="text-align: center;width:100%">
            <button class="atualizar" type="submit" style="border-radius: 10px;font-size:15px">Salvar</button>
            </div>
        </form>
    </div>
    <br>
@endsection