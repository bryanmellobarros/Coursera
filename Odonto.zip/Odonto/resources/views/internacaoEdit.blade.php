@extends('layouts.index')
@section('conteudo')
    <style>
        .return_btn{
            display: flex;
            align-items: center;
            background-color: white;
            width: 100px;
        }
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; /* Remove qualquer sombra */
            border: 2px solid;
            border-color: lightgray;
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        .formulario {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content:start;
            align-items: center
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .btn_add {
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            height: 35px;
        }
        .btn_add:hover {
            background-color: #4100f3;
        }
    </style>
    <div style="background-color: white;">
        <div style="border-radius: 10px; background-color:lightgray" class="return_btn">
            <a href="{{route('site.pacientesEdit', $data[0]['paciente_id'])}}"><span class="material-symbols-outlined">arrow_back</span></a><span style="padding-left: 5px;">Retornar</span>
        </div>
    </div>
    <hr>
    @component('forms.internacoesData', ['data'=>$data, 'nome_btn'=>'Atualizar'])
        
    @endcomponent
    <hr><br>
    <div style="text-align: right;padding-right:35px">
        <a href="{{route('site.diaAdd', $data[0]['id'])}}"><button class="btn_add">Adicionar Atendimento</button></a>
    </div>
    <br>
    <h2>Dias de Atendimentos:</h2>
    <div class="table">
        <table>
            <thead>
                <tr>
                    <th>DATA</th>
                    <th>ODONTOLOGISTA</th>
                    <th>PRESCRIÇÃO</th>
                    <th>OBSERVAÇÕES</th>
                    <th>Opções</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data2 as $d2)
                    <tr>
                        <td>{{ $d2['data'] }}</td>
                        <td>{{ $d2['odontologista'] }}</td>
                        <td>{{ $d2['prescricao'] }}</td>
                        <td>{{ $d2['observacoes'] }}</td>
                        <td><a href="{{route('site.diaEdit', $d2['id'])}}"><span class="material-symbols-outlined">chevron_right</span></a></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <br>
        <br>
    </div>
@endsection