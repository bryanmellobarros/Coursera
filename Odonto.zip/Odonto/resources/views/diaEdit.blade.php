@extends('layouts.index')
@section('conteudo')
    <style>
        .return_btn{
            display: flex;
            align-items: center;
            background-color: white;
            width: 100px;
        }
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        /*input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; 
            border: 2px solid;
            border-color: lightgray;
        }*/
        .formulario_edit {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content: center;
            align-items: center
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
    </style>
    <div style="background-color: white;">
        <div style="border-radius: 10px; background-color:lightgray" class="return_btn">
            <a href="{{route('site.internacaoEdit', $data[0]['internacao_id'])}}"><span class="material-symbols-outlined">arrow_back</span></a><span style="padding-left: 5px;">Retornar</span>
        </div>
    </div>
    <hr>
    @component('forms.diaData', ['data'=>$data, 'nome_btn'=>'Atualizar'])
        
    @endcomponent
@endsection