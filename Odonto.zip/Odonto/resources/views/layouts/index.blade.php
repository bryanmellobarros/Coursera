<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Exemplo</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100..900&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class='logo'>
                <img width="80" height="80" src="{{asset('img/logo.svg')}}">
            </div>
            <div class="user_button">
            @php
                $nome = $_SESSION['nome'];
            @endphp
            <button class="user_btn">Olá {{$nome}}</button>
            </div>
        </div>
        <div id="sidebar" class="sidebar">
            <ul>
                <li><a href="#"><span class="material-symbols-outlined">data_thresholding</span></a><a href="#"> Dashboards</a></li>
                <li><a href="{{ route('site.pacientes') }}"><span class="material-symbols-outlined">density_small</span></a><a href="{{ route('site.pacientes') }}"> Lista de Pacientes</a></li>
                <li><a href="#"><span class="material-symbols-outlined">stacks</span></a><a href="#"> Documentos</a></li>
            </ul>
            <button id="toggleButton" class="toggle-button">
                <span id="buttonOpen" class="material-symbols-outlined">arrow_back_ios</span>
                <span id="buttonClose" style="display: none" class="material-symbols-outlined">arrow_forward</span>
            </button>
        </div>
    </div>
    <hr class="linha">
    <div class='conteudo' id="conteudo">
        @yield('conteudo')
    <div>

    <script>
        document.getElementById('toggleButton').addEventListener('click', function() {
            const sidebar = document.getElementById('sidebar');
            const buttonOpen = document.getElementById('buttonOpen');
            const buttonClose = document.getElementById('buttonClose');
            const conteudo = document.getElementById('conteudo');
            
            sidebar.classList.toggle('collapsed');
            conteudo.classList.toggle('normal')

            if (sidebar.classList.contains('collapsed')) {
                buttonOpen.style.display = 'none';
                buttonClose.style.display = 'block';
            } else {
                buttonOpen.style.display = 'block';
                buttonClose.style.display = 'none';
            }
        });
    </script>
</body>
</html>
