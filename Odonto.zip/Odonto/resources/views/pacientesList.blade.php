@extends('layouts.index')
@section('conteudo')
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .search-container {
            max-width: 600px;
            margin: auto;
        }
        .search-container input[type="text"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .search-container button {
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            cursor: pointer;
        }
        .search-container button:hover {
            background-color: #4100f3;
        }
        .btn_add {
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            height: 35px;
        }
        .btn_add:hover {
            background-color: #4100f3;
        }
    </style>
    <br>
    <div style="display: flex">
        <div class="search-container" style="flex: 70%">
            <form action="{{route('site.pacientesFilter')}}" method="GET">
                <input type="text" name="query" placeholder="Nome do Paciente" required>
                <button type="submit">Buscar</button>
            </form>
        </div>
        <div style="padding-right: 35px">
            <a href="{{route('site.pacienteAdd')}}"><button class="btn_add">Adicionar Paciente</button></a>
        </div>
    </div>
    <br>
    <br>
    <div>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>IDSJB</th>
                    <th>Data de Nascimento</th>
                    <th>Sexo</th>
                    <th>Opções</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($data as $d)
                    <tr>
                        <td>{{ $d['nome'] }}</td>
                        <td>{{ $d['idsjb'] }}</td>
                        <td>{{ $d['data_de_nascimento'] }}</td>
                        <td>{{ $d['sexo'] }}</td>
                        <td><a href="{{route('site.pacientesEdit', $d['id'])}}"><span class="material-symbols-outlined">edit</span></a></td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection