<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Login</title>
    <style>
        /* Definindo o estilo básico para o corpo da página */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Estilo do container do formulário */
        .login-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .input-field {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .input-field:focus {
            outline: none;
            border-color: #007BFF;
        }

        .btn-login {
            width: 100%;
            padding: 12px;
            background-color: #1500f8;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-login:hover {
            background-color: #0056b3;
        }

        /* Estilo para os links de "Esqueci a senha" */
        .forgot-password {
            display: block;
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }

        .forgot-password a {
            color: #007BFF;
            text-decoration: none;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class='logo' style="position: absolute;top:10px;left:45,5%">
        <img width="150" height="150" src="{{asset('img/logo.svg')}}">
    </div>
    <div class="login-container">
        <h2>Login</h2>
        <form action="{{route('site.login')}}" method="POST">
            @csrf
            <input type="text" name="username" class="input-field" placeholder="Usuário" required>
            {{$errors->has('username') ? $errors->first('username') : ''}}
            <input type="password" name="password" class="input-field" placeholder="Senha" required>
            {{$errors->has('password') ? $errors->first('password') : ''}}
            <button type="submit" class="btn-login">Entrar</button>
        </form>
        <div class="forgot-password">
            <a href="#">Esqueci a senha</a>
        </div>
        <br>
        <div style="text-align: center">
        {{$erro}}
        </div>
    </div>

</body>
</html>