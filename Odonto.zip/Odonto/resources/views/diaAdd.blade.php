@extends('layouts.index')
@section('conteudo')
@php
    $opcoesCheckbox = [
        'biofilme_visivel',
        'saburra_lingual',
        'tartaro',
        'aresta',
        'sangramento',
        'carie',
        'raiz_ou_raizes_residuais',
        'sinal_flogisticos'
    ];

    $opcoesCheckbox2 = [
        'edentado_total_superior',
        'edentado_total_inferior',
        'edentado_parcial_superior',
        'edentado_parcial_inferior',
        'dentado_total_superior',
        'dentado_total_inferior'
    ];

    $opcoesCheckbox3 = [
        'solucao_enzimatica',
        'clorexidine_0,12%',
        'clorexidine_gel_0,2%',
        'saliva_artificial',
        'bepantol_baby',
        'higienizacao_proteses',
        'aspiracao_orofaringe',
        'secretivo',
        'laser',
        'restauracao',
        'extracao',
        'sutura',
        'protese',
    ];

@endphp
    <style>
        label {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            font-style: normal;
            font-size: 25px;
        }
        /*input{
            border-radius: 10px;
            height: 25px;
            width: 250px;
            box-shadow: none; 
            border: 2px solid;
            border-color: lightgray;
        }*/
        .formulario {
        display: flex; /* Ativa o Flexbox */
        gap: 20px; /* Espaço entre as colunas */
        }

        .primeira_coluna,
        .segunda_coluna {
            flex: 1; /* Faz com que ambas as colunas ocupem a mesma largura */
            padding: 10px; /* Espaçamento interno */
            box-sizing: border-box; /* Inclui padding e border no total da largura */
            align-content: center;
            align-items: center
        }
        select{
            height: 25px;
            width: 250px;
            border-radius: 10px;
            border: 2px solid;
            border-color: lightgray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center; /* Centraliza o texto nas células */
        }
        th {
            background-color: #f2f2f2;
        }
        .table{
            padding-right: 10px;
        }
        .segunda_linha{
            padding-left: 10px;
        }
        textarea{
            width: 600px; /* Largura da caixa */
            height: 100px; /* Altura da caixa */
            resize: none; /* Desativa a redimensionamento da caixa */
            border-radius: 10px;
            overflow: auto; /* Adiciona barra de rolagem se necessário */
            border: 2px solid;
            border-color: lightgray;
        }
        .enter_internacao .finish_internacao{
            height: 10px;
            width: 10px;
        }
        .btn_add {
            border-radius: 4px;
            background-color: #4000ff;
            color: white;
            height: 35px;
        }
        .btn_add:hover {
            background-color: #4100f3;
        }
        .return_btn{
            display: flex;
            align-items: center;
            background-color: white;
            width: 100px;
        }
    </style>
    <div style="background-color: white;">
        <div style="border-radius: 10px; background-color:lightgray" class="return_btn">
            <a href="{{route('site.internacaoEdit', $id)}}"><span class="material-symbols-outlined">arrow_back</span></a><span style="padding-left: 5px;">Retornar</span>
        </div>
    </div>
    <div>
        <h1>Adicionando atendimento para Internação: {{$id}}</h1>
        <hr>
    </div>
    <div>
        <form action="{{route('site.diaAdd', $id)}}" method="POST">
            @csrf
            <div class="formulario" style="display: flex">
                <div class="primeira_coluna" style="flex: 1;border-right:2px solid;align-content:flex-start">
                    @php
                        $dateTime = new DateTime();
                        $datetime2 = $dateTime->format('Y-m-d');
                        $datetime = $dateTime->format('d/m/Y');
                    @endphp
                    <input type="hidden" value="{{$datetime2}}" name="data">
                    @php
                        session_start();
                        $dentista = $_SESSION['nome']
                    @endphp
                    <input type="hidden" value="{{$dentista}}" name="odontologista">
                    <h2>Atendimento no dia: {{$datetime}}</h2>
                    <label>Sedação</label><br>
                        <select name="sedacao"><option value="1">Sedado</option><option value="2">Acordado</option><option value="3">Sonolento</option><option value="4">Responsivo aos Comandos</option><option value="5">Lote</option><option value="6">Abertura Ocular Espontânea</option><option value="7">Interagindo</option><option value="8" >Colaborativo</option></select>
                    <br><br>
                    <label>Ventilação</label><br>
                        <select name="ventilacao"><option value="1">Ar Ambiente</option><option value="2">Cateter de O2</option><option value="3">Macronebulização</option><option value="4">VNI</option><option value="5">TQT</option><option value="6">TOT</option><option value="7" >VM Modo Ventilatório</option><option value="8">Colaborativo</option></select>
                    <br><br>
                    <label>Mucosas</label><br>
                        <select name="mucosas"><option value="1">Normocrônicas</option><option value="2">Hipocrônicas</option><option value="3">Hiperemiadas</option><option value="4">Hipohidratadas</option><option value="5">Hidratadas</option><option value="6">Hígidas</option><option value="7" >Lesão</option></select>
                    <br><br>
                    <label>Salivação</label><br>
                        <select name="salivacao"><option value="1">Normal</option><option value="2">Xerostomia</option><option value="3">Hipossalivação</option><option value="4" >Babação</option></select>
                    <br><br>
                    <div class="multiplas_escolhas" style="display: flex">
                        <div class="presenca" style="flex: 1">
                            <label>Presença</label><br>
                            @foreach ($opcoesCheckbox as $item)
                                    <input type="checkbox" value={{$item}} name="presenca[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @endforeach
                        </div>
                        <div class="dentes" style="flex: 1">
                            <label>Dentes</label><br>
                            @foreach ($opcoesCheckbox2 as $item)
                                <input type="checkbox" value={{$item}} name="dentes[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                            @endforeach
                        </div>
                    </div>
                </div>
                <div class="segunda_coluna" style="flex: 1;align-content:flex-start;padding-top:80px">
                    <label>Conduta</label><br>
                    @foreach ($opcoesCheckbox3 as $item)
                        <input type="checkbox" value={{$item}} name="conduta[]" id='{{$item}}'>{{ ucwords(str_replace('_', ' ', $item)) }}<br>
                    @endforeach
                    <br><br>
                    <label>Prescrição</label><br>
                    <textarea name="prescricao"></textarea><br><br>
                    <label>Observações</label><br>
                    <textarea name="observacoes"></textarea><br><br>
                    <label>Intercorrencias</label><br>
                    <textarea name="intercorrencias"></textarea><br><br>
                </div>
            </div>
            <br>
            <div style="text-align: center;width:100%">
                <button class="salvar" type="submit" style="border-radius: 10px;font-size:15px">Salvar</button>
            </div>
        </form>
        <br>
    <div>
@endsection