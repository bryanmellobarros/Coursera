<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dias', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('internacao_id');
            $table->date('data');
            $table->integer('sedacao')->nullable();
            $table->integer('ventilacao')->nullable();
            $table->integer('mucosas')->nullable();
            $table->text('hipotese_diagnostica')->nullable();
            $table->text('presenca')->nullable();
            $table->integer('salivacao')->nullable();
            $table->text('dentes')->nullable();
            $table->text('conduta')->nullable();
            $table->text('prescricao')->nullable();
            $table->text('observacoes')->nullable();
            $table->text('intercorrencias')->nullable();
            $table->string('odontologista',50);
            $table->timestamps();

            $table->foreign('internacao_id')->references('id')->on('internacaos');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('dias', function (Blueprint $table) {
            $table->dropForeign('dias_internacao_id_foreign');
            $table->dropColumn('internacao_id');
        });
        Schema::dropIfExists('dias');
    }
};
