<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('internacaos', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('paciente_id');
            $table->date('data_de_entrada');
            $table->date('data_de_saida')->nullable();
            $table->text('motivo_da_internacao')->nullable();
            $table->text('pa')->nullable();
            $table->text('sato2')->nullable();
            $table->text('fc')->nullable();
            $table->text('fr')->nullable();
            $table->text('temp')->nullable();
            $table->text('dieta')->nullable();
            $table->integer('bomba_de_infusao')->nullable();
            $table->integer('hemodialise')->nullable();
            $table->integer('risco_de_tev')->nullable();
            $table->text('conduta_profilatica_tev')->nullable();
            $table->timestamps();

            $table->foreign('paciente_id')->references('id')->on('pacientes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('internacaos', function (Blueprint $table) {
            $table->dropForeign('internacaos_paciente_id_foreign');
            $table->dropColumn('paciente_id');
        });
        Schema::dropIfExists('internacaos');
    }
};
