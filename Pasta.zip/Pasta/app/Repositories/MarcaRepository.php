<?php

namespace App\Repositories;

class MarcaRepository extends AbstractRepository {

}

?>