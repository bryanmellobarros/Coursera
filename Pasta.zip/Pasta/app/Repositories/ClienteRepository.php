<?php

namespace App\Repositories;

class ClienteRepository extends AbstractRepository {

}

?>