<?php

namespace App\Repositories;

class LocacaoRepository extends AbstractRepository {

}

?>