<?php

namespace App\Repositories;

class ModeloRepository extends AbstractRepository {
}

?>