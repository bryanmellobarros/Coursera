<?php

namespace App\Repositories;

class CarroRepository extends AbstractRepository {

}

?>