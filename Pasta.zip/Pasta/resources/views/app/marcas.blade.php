@extends('layouts.app')

@section('content')
    <marcas-component></marcas-component>
@endsection
